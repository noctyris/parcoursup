#! C:\laragon\bin\python\python-3.6.1\python.exe
# -*- coding: UTF-8 -*-

import cgi, cgitb
import sys
import codecs
import csv

cgitb.enable()
sys.stdout = codecs.getwriter("utf-8")(sys.stdout.detach())

def lecture_csv(fichier, delimiteur):
    """
    Paramètres :
        un chemin vers un fichier CSV,
        le délimiteur utilisé dans ce fichier
    Valeur renvoyée : un tableau de dictionnaires, extraction de la table contenue dans le fichier
    """
    
    with open(fichier, 'r', encoding = 'utf8') as f:
        reader = csv.DictReader(f, delimiter = delimiteur) #création d'un objet reader
        table = [dict(enregistrement) for enregistrement in reader]
    
    return table


print ("Content-type:text/html\r\n\r\n")
print('<!DOCTYPE html>')
print ('<html>')
print ('<head>')
print ('<title>Exemple</title>')
print ('''
      <meta charset="utf-8">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css" />
''')

print ('</head>')
print ('<body>')

#ici débute le contenu <body>
print('<div>')

#ici débute le contenu modifiable

data = lecture_csv('../parcoursup.csv', ";")
formulaire = cgi.FieldStorage()
spe1, spe2, formation = formulaire.getvalue('spe1'), formulaire.getvalue('spe2'), formulaire.getvalue('formation')

print(f'<p>Spé 1: {spe1}</p><p>Spé 2: {spe2}</p><p>Formation 1: {formation}</p>')

print ('</body>')
print ('</html>')
