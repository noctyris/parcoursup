import csv

def lecture_csv(fichier, delimiteur):
    """
    Paramètres :
        un chemin vers un fichier CSV,
        le délimiteur utilisé dans ce fichier
    Valeur renvoyée : un tableau de dictionnaires, extraction de la table contenue dans le fichier
    """
    
    with open(fichier, 'r', encoding = 'utf-8-sig') as f:
        reader = csv.DictReader(f, delimiter = delimiteur) #création d'un objet reader
        table = [dict(enregistrement) for enregistrement in reader]
    
    return table

a = lecture_csv('parcoursup.csv', ';')
b = set()
for i in a:
    b.add(i['Formation'])
for i in b:
    print(f'<option>{i}</option>')